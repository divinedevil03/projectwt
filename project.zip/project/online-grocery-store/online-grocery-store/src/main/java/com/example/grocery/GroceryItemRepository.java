package com.example.grocery;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GroceryItemRepository extends JpaRepository<GroceryItem, Long> {
    List<GroceryItem> findByNameContaining(String name);
    List<GroceryItem> findByCategory(String category);
}
