package com.example.grocery;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroceryItemService {
    private final GroceryItemRepository groceryItemRepository;

    public GroceryItemService(GroceryItemRepository groceryItemRepository) {
        this.groceryItemRepository = groceryItemRepository;
    }

    public List<GroceryItem> getAllItems() {
        return groceryItemRepository.findAll();
    }

    public GroceryItem getItemById(Long id) {
        return groceryItemRepository.findById(id).orElseThrow(() -> new RuntimeException("Item not found"));
    }

    public GroceryItem addItem(GroceryItem item) {
        return groceryItemRepository.save(item);
    }

    public GroceryItem updateItem(Long id, GroceryItem itemDetails) {
        GroceryItem item = getItemById(id);
        item.setName(itemDetails.getName());
        item.setDescription(itemDetails.getDescription());
        item.setPrice(itemDetails.getPrice());
        item.setQuantityInStock(itemDetails.getQuantityInStock());
        item.setCategory(itemDetails.getCategory());
        return groceryItemRepository.save(item);
    }

    public void deleteItem(Long id) {
        groceryItemRepository.deleteById(id);
    }

    public List<GroceryItem> searchItemsByName(String name) {
        return groceryItemRepository.findByNameContaining(name);
    }

    public List<GroceryItem> searchItemsByCategory(String category) {
        return groceryItemRepository.findByCategory(category);
    }
}
