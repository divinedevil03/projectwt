package com.example.taskmanagement.controller;

import com.example.taskmanagement.model.*;
import com.example.taskmanagement.service.*;

import jakarta.validation.Valid;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/tasks")
public class TaskController {
	
	private final TaskService taskService;

    // Constructor Injection
    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    // GET /tasks - Retrieve all tasks
    @GetMapping
    public String getAllTasks(Model model, @RequestParam(value = "status", required = false) Status status) {
        List<Task> tasks;
        if (status != null) {
            tasks = taskService.getTasksByStatus(status);
            model.addAttribute("statusFilter", status);
        } else {
            tasks = taskService.getAllTasks();
        }
        model.addAttribute("tasks", tasks);
        model.addAttribute("statuses", Status.values());
        return "task-list"; // Thymeleaf template
    }

    // GET /tasks/new - Show form to create a new task
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        Task task = new Task();
        task.setStatus(Status.PENDING); // Default status
        model.addAttribute("task", task);
        model.addAttribute("statuses", Status.values());
        return "task-form"; // Thymeleaf template
    }

    // POST /tasks - Create a new task
    @PostMapping
    public String createTask(@Valid @ModelAttribute("task") Task task) {
        taskService.createTask(task);
        return "redirect:/tasks";
    }

    // GET /tasks/edit/{id} - Show form to edit a task
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Task task = taskService.getTaskById(id)
                .orElseThrow(() -> new RuntimeException("Task not found with id " + id));
        model.addAttribute("task", task);
        model.addAttribute("statuses", Status.values());
        return "task-form"; // Reuse the same form for editing
    }

    // POST /tasks/update/{id} - Update an existing task
    @PostMapping("/update/{id}")
    public String updateTask(@PathVariable("id") Long id, @Valid @ModelAttribute("task") Task task) {
        taskService.updateTask(id, task);
        return "redirect:/tasks";
    }

    // POST /tasks/delete/{id} - Delete a task
    @PostMapping("/delete/{id}")
    public String deleteTask(@PathVariable("id") Long id) {
        taskService.deleteTask(id);
        return "redirect:/tasks";
    }

}
