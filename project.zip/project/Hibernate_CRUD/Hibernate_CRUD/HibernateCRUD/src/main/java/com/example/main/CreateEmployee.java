
package com.example.main;

import com.example.model.Employee;
import com.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateEmployee {
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JButton submitButton;

    public CreateEmployee() {
        // Create JFrame
        JFrame frame = new JFrame("Create Employee");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 300);
        frame.setLayout(null);

        // Create fields and labels
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(10, 20, 80, 25);
        frame.add(firstNameLabel);
        
        firstNameField = new JTextField();
        firstNameField.setBounds(100, 20, 165, 25);
        frame.add(firstNameField);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(10, 60, 80, 25);
        frame.add(lastNameLabel);
        
        lastNameField = new JTextField();
        lastNameField.setBounds(100, 60, 165, 25);
        frame.add(lastNameField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(10, 100, 80, 25);
        frame.add(emailLabel);
        
        emailField = new JTextField();
        emailField.setBounds(100, 100, 165, 25);
        frame.add(emailField);

        // Create submit button
        submitButton = new JButton("Submit");
        submitButton.setBounds(10, 140, 255, 25);
        frame.add(submitButton);

        // Add action listener for the button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createEmployee();
            }
        });

        // Set frame visibility
        frame.setVisible(true);
    }

    private void createEmployee() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();
            
            // Create a new employee
            Employee employee = new Employee();
            employee.setFirstName(firstNameField.getText());
            employee.setLastName(lastNameField.getText());
            employee.setEmail(emailField.getText());
            
            // Save the employee to the database
            session.save(employee);
            
            transaction.commit();
            JOptionPane.showMessageDialog(null, "Employee created successfully!");

            // Clear fields after submission
            firstNameField.setText("");
            lastNameField.setText("");
            emailField.setText("");
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error creating employee: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    public static void main(String[] args) {
        new CreateEmployee();
    }
}
