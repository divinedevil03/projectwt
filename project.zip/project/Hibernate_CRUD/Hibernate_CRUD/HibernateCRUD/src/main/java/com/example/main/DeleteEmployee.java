package com.example.main;

import com.example.model.Employee;
import com.example.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteEmployee {
    private JTextField employeeIdField;
    private JButton deleteButton;

    public DeleteEmployee() {
        // Create JFrame
        JFrame frame = new JFrame("Delete Employee");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setLayout(null);

        // Create field and label for employee ID
        JLabel employeeIdLabel = new JLabel("Employee ID:");
        employeeIdLabel.setBounds(10, 20, 80, 25);
        frame.add(employeeIdLabel);

        employeeIdField = new JTextField();
        employeeIdField.setBounds(100, 20, 165, 25);
        frame.add(employeeIdField);

        // Create delete button
        deleteButton = new JButton("Delete");
        deleteButton.setBounds(10, 60, 255, 25);
        frame.add(deleteButton);

        // Add action listener to the button
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteEmployee();
            }
        });

        // Set frame visibility
        frame.setVisible(true);
    }

    private void deleteEmployee() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();
            
            // Retrieve and delete the employee based on ID
            int employeeId = Integer.parseInt(employeeIdField.getText());
            Employee employee = session.get(Employee.class, employeeId);
            
            if (employee != null) {
                session.delete(employee);
                transaction.commit();
                JOptionPane.showMessageDialog(null, "Employee deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Employee not found!");
            }
            
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error deleting employee: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    public static void main(String[] args) {
        new DeleteEmployee();
    }
}
